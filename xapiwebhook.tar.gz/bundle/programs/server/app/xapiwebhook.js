(function(){Statements = new Meteor.Collection('statements');
Hooks = new Meteor.Collection('hooks');
LRSHooks = new Meteor.Collection('lrshooks');

if (Meteor.isClient) {
  // counter starts at 0
//  Session.setDefault('counter', 0);
    Session.setDefault('hookID', undefined);

    Template.stmts.helpers({
        statement: function() {
            return Statements.find({}, {sort: {_timestamp: -1}}).fetch().map(function (c, i, a) {
                return decodeKeys(c);
            });
        }
    });
    
    Template.body.events({
        'click #hook': function (event) {
            console.log(Session.get('hookID'));
            console.log(event);
            if (Session.get('hookID')) {
                Meteor.call('unregisterHook', function (err, res) {
                    if (!err) {
                        Session.set('hookID', res);
                        event.currentTarget.innerHTML = 'Hook';
                        console.log('hookid: ', Session.get('hookID'));
                    }
                    else console.log(err);
                });
            } else {
                Meteor.call('registerHook', function (err, res) {
                    if (!err) {
                        Session.set('hookID', res);
                        event.currentTarget.innerHTML = 'Unhook';
                        console.log('hookid: ', Session.get('hookID'));
                    }
                    else console.log(err);
                });
            }
        }
    });
}

if (Meteor.isServer) {
    Meteor.startup(function () {
    // code to run on server at startup
    });
}

Meteor.methods({
    registerHook: function () {
        HTTP.post('http://localhost:3000/xapi/me/statements/hooks');
        return 'the id';
    },
    unregisterHook: function () {
        return undefined;
    }
});

Router.route('/');
Router.route('/xapi/webhook', {where: 'server'})
    .post(function() {
        try {
//            console.log(this.request);
//            console.log(this.request.body);
            this.request.body.statements.forEach(function (cur, idx, arr){
                if ( !cur.timestamp ) cur.timestamp = (new Date()).toISOString();
                cur._timestamp = new Date(cur.timestamp);
                Statements.insert(encodeKeys(cur));
            });
            this.response.writeHead(200, {"Content-Type":"text/plain"});
            this.response.write("200 OK");
            this.response.end();
        } catch (e) {
            this.response.writeHead(500, {"Content-Type":"text/plain"});
            this.response.write(e.message);
            this.response.end();
        }
        
    });

//Router.route('/xapi/me/statements/hooks', {where: 'server'})
//    .post(function () {
//        try {
//            var hook = this.request.body;
//            var hid = LRSHooks.findOne({'name': hook.name});
//            if (!hid) {
//                hid = LRSHooks.insert(hook);
//            }
//            var loc = 'http://localhost:3000/xapi/me/statements/hooks/' + hid;
//            this.response.writeHead(201, {"Content-Type":"application/json", "Location":loc});
//            hook.id = hid;
//            hook.url = loc;
//            this.response.write(JSON.stringify(hook, null, 4));
////            this.response.write(JSON.stringify(hook, null, 4));
//            this.response.end();
//        } catch (e) {
//            this.response.writeHead(500, {"Content-Type":"text/plain"});
//            this.response.write(e.message);
//            this.response.end();
//        }
//    });
//Router.route('/xapi/me/statements/hooks/:id', {where: 'server'})
//    .delete(function () {
//        try {
//            console.log('delete..', this.params.id);
//            LRSHooks.remove({'_id':this.params.id});
//            this.response.writeHead(204);
//            this.response.end();
//        } catch (e) {
//            this.response.writeHead(500, {"Content-Type":"text/plain"});
//            this.response.write(e.message);
//            this.response.end();
//        }
//    });

var encodeKeys = function (stmt) {
    for( var key in stmt ) {
        if (stmt.hasOwnProperty(key) && stmt[key].extensions) {
            stmt[key].extensions = JSON.stringify(stmt[key].extensions);
        }
    }
    return stmt;
}

var decodeKeys = function (stmt) {
    for( var key in stmt ) {
        if (stmt.hasOwnProperty(key) && stmt[key].extensions) {
            stmt[key].extensions = JSON.parse(stmt[key].extensions);
        }
    }
    return stmt;
}

})();
