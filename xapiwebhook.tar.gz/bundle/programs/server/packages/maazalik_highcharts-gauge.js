(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['maazalik:highcharts-gauge'] = {};

})();

//# sourceMappingURL=maazalik_highcharts-gauge.js.map
