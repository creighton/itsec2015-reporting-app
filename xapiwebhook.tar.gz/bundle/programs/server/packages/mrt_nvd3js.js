(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:nvd3js'] = {};

})();

//# sourceMappingURL=mrt_nvd3js.js.map
